A Pen created at CodePen.io. You can find this one at https://codepen.io/namnv609/pen/rVqKRQ.

 Google Maps API JavaScript Services (Geocoder)