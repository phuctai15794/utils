(function() {
  $("#detail").on("click", function() {
    var address, geocoder;
    geocoder = new google.maps.Geocoder();
    address = $("#address").val().trim();
    if (address) {
      return geocoder.geocode({
        address: address
      }, function(results, status) {
        var addressDetail;
        if (status === google.maps.GeocoderStatus.OK) {

          /* Ở đây chúng ta sẽ có 1 mảng các object giá trị
           mà Google sẽ trả về. Các bạn có thể console.log
           nó ra để xem chi tiết. Ở demo này mình sẽ lấy
           thông tin của phần tử đầu tiên trong mảng nhé
           */
          addressDetail = "Address: " + results[0].formatted_address + "<br />\nLatitude: " + (results[0].geometry.location.lat()) + "<br />\nLongitude: " + (results[0].geometry.location.lng());
          return $("#result").html(addressDetail);
        } else {
          return alert(status);
        }
      });
    } else {
      return $("#address").focus();
    }
  });

}).call(this);