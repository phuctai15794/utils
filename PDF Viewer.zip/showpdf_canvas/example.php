
<div id="holder"></div>
<script src="pdf.js"></script>
<script>
  function renderPDF(url, canvasContainer, options) {
    var options = options || { scale: 1 };
    var pdfjsLib = window['pdfjs-dist/build/pdf'];
    function renderPage(page) {
        var viewport = page.getViewport(options.scale);
        var canvas = document.createElement('canvas');
        var ctx = canvas.getContext('2d');
        var renderContext = {
          canvasContext: ctx,
          viewport: viewport
        };
        
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        canvasContainer.appendChild(canvas);
        
        page.render(renderContext);
    }
    
    function renderPages(pdfDoc) {
        for(var num = 1; num <= pdfDoc.numPages; num++)
            pdfDoc.getPage(num).then(renderPage);
    }
    pdfjsLib.disableWorker = true;
    pdfjsLib.getDocument(url).then(renderPages);
}   
renderPDF('https://<?=$config_url?>/<?=_upload_hinhanh_l.$row_detail['file']?>', document.getElementById('holder'));
</script>
